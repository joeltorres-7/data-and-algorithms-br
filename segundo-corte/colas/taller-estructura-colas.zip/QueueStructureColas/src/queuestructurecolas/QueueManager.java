package queuestructurecolas;

public class QueueManager {
    Node cola;
    Node cima;

    // Decoradores

    String GREEN = "\u001B[32m";
    String RED = "\u001B[31m";
    String RESET = "\u001B[0m";

    // Inicializacion

    public QueueManager() {
        this.cima = null;
        this.cola = null;
    }

    // Metodos

    static void separatorLine() {
        System.out.println("- - - - - - - - - -");
    }

    // Insertar elemento a la cima.

    public void insertBottom(int data)
    {
        Node temp = new Node(data);
        if (cima == null) {
            cima = temp;
            cola = cima;
        } else if (queueSize() == 1) {
            temp.next = cima;
            cima.prev = temp;
            cola = temp;
        } else {
            Node temp1 = cola;
            temp1.prev = temp;
            temp.next = temp1;
            cola = temp;
        }
    }

    // Eliminar un elemento de la cima.

    public void deleteTop()
    {
        if (cima == null) {
            return;
        }
        if (queueSize() == 1){
            cima = null;
            cola = null;
            return;
        }

        Node temp = cima;
        cima = temp.prev;
        cima.next = null;
    }

    // Tamano de la pila.

    int queueSize() {
        Node current = cola;
        int stackCount = 0;

        if (cola == null) {
            System.out.println(RED + "La pila se encuentra vacia!" + RESET);
            return stackCount;
        }

        while(current != null) {
            stackCount++;
            current = current.next;
        }

        return stackCount;
    }

    // Imprimir pila actual.

    public void display() {
        if (cima == null) {
            System.out.println(RED + "La cola se encuentra vacia." + RESET);
            return;
        }

        System.out.println();
        System.out.println("    _  _");
        System.out.println("  _(   )_");
        System.out.println(" (_  ___)");
        System.out.println("   (_)   ");

        if (cima.next == cima) {
            System.out.print("| " + cima.value + " |\n");
            separatorLine();
            return;
        }

        System.out.println(GREEN);

        Node current = cima;

        do {
            System.out.print("| " + current.value + " |\n");
            separatorLine();
            current = current.prev;
        } while (current != null);
        System.out.println(RESET);
    }

    // Imprimir elemento de la cima.

    void bottomElement() {
        if (cola == null) {
            System.out.println(RED + "La pila se encuentra vacia!" + RESET);
            return;
        }

        System.out.println("El elemento de la cola es: " + cola.value);
    }
}
