public class StackManager {
    Node cima;

    // Decoradores

    String GREEN = "\u001B[32m";
    String CYAN = "\u001B[36m";
    String RED = "\u001B[31m";
    String RESET = "\u001B[0m";

    // Inicializacion

    public StackManager() {
        this.cima = null;
    }

    // Metodos

    static void separatorLine() {
        System.out.println("- - - - - - - - - -");
    }

    // Insertar elemento a la cima.

    public void insertTop(int data)
    {
        Node temp = new Node(data);
        if (cima == null) {
            cima = temp;
        }
        else {
            temp.next = cima;
            cima = temp;
        }
    }

    // Eliminar un elemento de la cima.

    public void deleteTop()
    {
        if (cima == null) {
            return;
        }

        if (stackSize() == 1) {
            cima = null;
            return;
        }

        Node temp = cima;
        cima = cima.next;
        temp.next = null;
    }

    // Tamano de la pila.

    int stackSize() {
        Node current = cima;
        int stackCount = 0;

        if (cima == null) {
            System.out.println(RED + "La pila se encuentra vacia!" + RESET);
            return stackCount;
        }

        while(current != null) {
            stackCount++;
            current = current.next;
        }

        return stackCount;
    }

    // Imprimir pila actual.

    public void display() {
        if (cima == null) {
            System.out.println(RED + "La pila se encuentra vacia." + RESET);
            return;
        }

        System.out.println();
        System.out.println("    _  _");
        System.out.println("  _(   )_");
        System.out.println(" (_  ___)");
        System.out.println("   (_)   ");

        if (cima.next == cima) {
            System.out.print("| " + cima.value + " |\n");
            separatorLine();
            return;
        }

        System.out.println(GREEN);

        Node current = cima;

        do {
            System.out.print("| " + current.value + " |\n");
            separatorLine();
            current = current.next;
        } while (current != null);
        System.out.println(RESET);
    }

    // Imprimir elemento de la cima.

    void topElement() {
        if (cima == null) {
            System.out.println(RED + "La pila se encuentra vacia!" + RESET);
            return;
        }

        System.out.println("El elemento de la cima es: " + cima.value);
    }
}
