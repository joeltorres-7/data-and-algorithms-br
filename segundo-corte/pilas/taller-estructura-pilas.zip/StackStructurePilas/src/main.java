import java.util.Scanner;

public class main {
    // Decoradores

    static void separatorLine() {
        System.out.println("- - - - - - - - - -");
    }

    // Menu

    public static void runMenu(StackManager stackManager) {
        String RESET = "\u001B[0m";
        String GREEN = "\u001B[32m";
        String RED = "\u001B[31m";
        StackManager stackManagerList = stackManager;
        Scanner scanner = new Scanner(System.in);
        int userOption = 0;

        // Menu y Operaciones.

        System.out.println("*** Menu de Usario ***");
        System.out.println("(1) Agregar nuevo elemento a la cima.");
        System.out.println("(2) Eliminar un elemento de la cima.");
        System.out.println("(3) Imprimir pila.");
        System.out.println("(4) Imprimir tamano de la pila.");
        System.out.println("(5) Imprimir cima.");
        System.out.println("(6) Salir.");

        while(userOption <= 0) {
            System.out.print("Opcion: ");
            try {
                userOption = scanner.nextInt();
            } catch(Exception e) {
                System.out.println("Opcion incorrecta. Ingrese un numero.");
            }
        }

        // Condiciones

        switch (userOption) {
            case 1:
                int topValue;

                System.out.print("Ingrese el valor: ");
                topValue = scanner.nextInt();
                System.out.println();

                try {
                    stackManagerList.insertTop(topValue);
                    System.out.println(GREEN + "Elemento agregado con exito!" + RESET);
                } catch (Exception e) {
                    System.out.println(RED +"Recuerde, solo numeros positivos." + RESET);
                }

                break;
            case 2:
                if (stackManager.stackSize() != 0) {
                    stackManager.deleteTop();
                    System.out.println(GREEN + "Cima eliminada con exito!" + RESET);
                } else {
                    System.out.println(RED + "Ya no hay elementos para eliminar." + RESET);
                }

                break;
            case 3:
                stackManager.display();
                break;
            case 4:
                separatorLine();
                System.out.println(GREEN + "Tamano de la lista: " + RESET + stackManager.stackSize());
                separatorLine();
                break;
            case 5:
                stackManager.topElement();
                break;
            case 6:
                System.exit(0);
                break;
        }

        runMenu(stackManagerList);
    }

    public static void main(String[] args) {
        String RESET = "\u001B[0m";
        String CYAN = "\u001B[36m";
        String GREEN = "\u001B[32m";

        // Inicializa la lista de polinomios.

        StackManager stackManager = new StackManager();
        Scanner scanner = new Scanner(System.in);
        int userOption = 0;

        // Codigo de Operaciones

        System.out.println(CYAN + "Nombre del Proyecto: Pila" + RESET);
        separatorLine();
        System.out.println(CYAN + "Integrantes:" + RESET +
                "\n* Jerley Saieth Hernandez Calvo" +
                "\n* Nelmer Daniel Roa Cardenas" +
                "\n* Joel Alejandro Torres Canas");
        separatorLine();

        runMenu(stackManager);
    }
}
