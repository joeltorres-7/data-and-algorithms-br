public class CircularLinkedList {

    // Variables Principales

    Node head;
    Node currentNode;

    // Decoradores

    String GREEN = "\u001B[32m";
    String YELLOW = "\u001B[33m";
    String RED = "\u001B[31m";
    String RESET = "\u001B[0m";

    // Constructor

    public CircularLinkedList() {
        this.head = null;
        this.currentNode = null;
    }

    // Obtener el nodo actual.

    void setCurrentToHead() {
        currentNode = head;
    }

    void goNextNode() {
        if (currentNode == null) {
            setCurrentToHead();
            return;
        }
        currentNode = currentNode.next;
    }

    public void showCurrentPosition() {
        if (currentNode == null) {
            setCurrentToHead();
        }

        System.out.print("* El elemento actual es: " + currentNode.data);
    }

    // Comprobar tamano de lista

    int listSize() {
        int size = 0;
        Node temp = head;
        if (temp == null) {
            return size;
        }
        do {
            size++;
            temp = temp.next;
        } while (temp != head);
        return size;
    }

    // Agregar nodo al final.

    void insertAtBeginning(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            head.next = head;
        } else {
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.next = head;
            head = newNode;
        }
    }

    // Agregar nodo al inicio.

    void insertAtEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            head.next = head;
        } else {
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.next = head;
        }
    }

    void insertAtPosition(int data, int position) {
        Node newNode = new Node(data);
        if (position <= 0) {
            System.out.println(RED + "Posicion invalida" + RESET);
            return;
        }
        if (head == null && position != 1) {
            System.out.println("La lista esta vacia, no se puede agregar en la posicion: " + position);
            return;
        }
        if (position == 1) {
            newNode.next = head;
            head = newNode;
            return;
        }
        Node temp = head;
        int count = 1;
        while (count < position - 1 && temp.next != head) {
            temp = temp.next;
            count++;
        }
        if (count == position - 1) {
            newNode.next = temp.next;
            temp.next = newNode;
        } else {
            System.out.println(RED + "ALETA: La posicion " + position + " excede la longitud de la lista." + RESET);
        }
    }

    void deleteAtBeginning() {
        if (head == null) {
            System.out.println(RED + "ALERTA: La lista ya esta vacia. No se puede eliminar." + RESET);
            return;
        }
        Node temp = head;
        while (temp.next != head) {
            temp = temp.next;
        }
        if (head == temp) {
            head = null;
        } else {
            head = head.next;
            temp.next = head;
        }
    }

    void deleteAtEnd() {
        if (head == null) {
            System.out.println(RED + "ALERTA: La lista ya esta vacia. No se puede eliminar." + RESET);
            return;
        }
        Node temp = head;
        Node prev = null;
        while (temp.next != head) {
            prev = temp;
            temp = temp.next;
        }
        if (prev != null) {
            prev.next = head;
        } else {
            head = null;
        }
    }

    void deleteAtSpecificPosition(int position) {
        if (head == null) {
            System.out.println(RED + "ALERTA: La lista ya esta vacia. No se puede eliminar." + RESET);
            return;
        }
        if (position <= 0) {
            System.out.println(RED + "ALERTA: Posicion invalida." + RESET);
            return;
        }
        if (position == 1) {
            deleteAtBeginning();
            return;
        }
        Node temp = head;
        Node prev = null;
        int count = 1;
        while (count < position && temp.next != head) {
            prev = temp;
            temp = temp.next;
            count++;
        }
        if (count == position) {
            prev.next = temp.next;
        } else {
            System.out.println(RED + "ALETA: La posicion " + position + " excede la longitud de la lista." + RESET);
        }
    }

    void display() {
        if (head == null) {
            System.out.println(RED + "La lista circular se encuentra vacia." + RESET);
            return;
        }
        System.out.println(GREEN);
        Node current = head;
        do {
            System.out.print(current.data + " -> ");
            current = current.next;
        } while (current != head);
        System.out.println(RESET);
    }
}

