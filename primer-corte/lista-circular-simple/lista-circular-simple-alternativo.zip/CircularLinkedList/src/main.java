// Bienvenido al codigo de Listas Circulares Simples del Grupo 4 para la materia de Estructura de Datos y Analisis de Algoritmos BR en la Universidad de Pamplona.

// El codigo base para este ejemplo fue obtenido de la fuente: https://www.geeksforgeeks.org/introduction-to-doubly-linked-lists-in-java/
// El codigo teorico para listas circulares simples fue tomado de la fuente: https://www.geeksforgeeks.org/circular-linked-list/

public class main {

    // Decoradores: Separadores

    static void separatorLine() {
        System.out.println("- - - - - - - - - -");
    }

    public static void main(String[] args) {
        // Decoradores: Colores

        String RESET = "\u001B[0m";
        String CYAN = "\u001B[36m";
        String GREEN = "\u001B[32m";

        // Codigo de Operaciones

        System.out.println(CYAN + "Nombre del Proyecto: Lista Circular Simple" + RESET);
        separatorLine();
        System.out.println(CYAN + "Integrantes:" + RESET +
                "\n* Jerley Saieth Hernandez Calvo" +
                "\n* Nelmer Daniel Roa Cardenas" +
                "\n* Joel Alejandro Torres Canas");
        separatorLine();

        System.out.println(CYAN + "\n*** Operaciones realizadas a la lista ***\n" + RESET);

        // Se inicializa la lista y se agregan los elementos iniciales.

        CircularLinkedList circularLinkedList = new CircularLinkedList();
        circularLinkedList.insertAtEnd(1);
        circularLinkedList.insertAtEnd(2);
        circularLinkedList.insertAtEnd(3);
        circularLinkedList.insertAtEnd(4);
        circularLinkedList.insertAtEnd(5);

        // Comprobamos el tamano actual.

        System.out.println("* Tamano actual: " + circularLinkedList.listSize());

        // Mostramos la posicion actual y mostramos la lista.

        circularLinkedList.showCurrentPosition();
        circularLinkedList.display();

        // Se insertan elementos en cola y cabeza de la lista.

        System.out.print("* Lista tras insertar en Cola: ");
        circularLinkedList.display();

        System.out.print("* Lista tras insertar en Cabeza: ");
        circularLinkedList.insertAtBeginning(0);
        circularLinkedList.display();

        // Se navegan dos nodos hacia adelante.

        circularLinkedList.goNextNode();
        circularLinkedList.goNextNode();
        System.out.println("* Se ha movido 2 posiciones hacia adelante.");
        circularLinkedList.showCurrentPosition();
        circularLinkedList.display();

        // Se navega al inicio de la lista desde el final.

        System.out.println("* Se ha movido 3 posiciones hacia adelante.");
        circularLinkedList.goNextNode();
        circularLinkedList.goNextNode();
        circularLinkedList.goNextNode();
        circularLinkedList.showCurrentPosition();
        circularLinkedList.display();

        // Insertamos en la posicion 2 y mostramos la lista.

        circularLinkedList.insertAtPosition(6, 2);
        System.out.print("* Tras insertar en posicion 2: ");
        circularLinkedList.display();

        // Eliminamos un elemento al inicio.

        circularLinkedList.deleteAtBeginning();
        System.out.print(
                "* Se ha eliminado un elemento al inicio: ");
        circularLinkedList.display();

        // Comprobamos tamano de la lista.

        System.out.println("* Tamano actual: " + circularLinkedList.listSize());

        // Eliminamos un elemento al final y mostramos lista.

        circularLinkedList.deleteAtEnd();
        System.out.print("* Se ha eliminado un elemento al final: ");
        circularLinkedList.display();

        // Comprobamos tamano de la lista.

        System.out.println("* Tamano actual: " + circularLinkedList.listSize());

        // Eliminamos el elemento de la posicion 2 y mostramos lista.

        circularLinkedList.deleteAtSpecificPosition(2);
        System.out.print(
                "* Se ha eliminado el elemento de la posicion 2: ");
        circularLinkedList.display();

        // Fin del codigo.

        separatorLine();
        System.out.println(CYAN + "Fin de Operaciones :)" + RESET);
        separatorLine();
    }
}
