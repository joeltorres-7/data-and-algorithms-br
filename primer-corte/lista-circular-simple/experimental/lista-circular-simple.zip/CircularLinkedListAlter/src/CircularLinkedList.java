public class CircularLinkedList {

    // Variables Principales

    Node head;
    Node tail;
    Node currentNode;

    // Decoradores

    String GREEN = "\u001B[32m";
    String YELLOW = "\u001B[33m";
    String RESET = "\u001B[0m";

    // Constructor

    public CircularLinkedList() {
        this.head = null;
        this.tail = null;
        this.currentNode = null;
    }

    // Comprobar tamano de lista

    public int listSize() {
        int size = 0;
        Node current = head;
        while (current != null) {
            size++;
            current = current.next;
        }

        return size;
    }

    // Mostrar posicion actual

    public void showCurrentPosition() {
        if (currentNode == null) {
            currentNode = head;
        }

        System.out.print("* El elemento actual es: " + currentNode.data);
    }

    // Navegar/Cambiar a la siguiente posicion

    public void goNextNode() {
        currentNode = currentNode.next;
    }

    // Mostrar lista completa

    public void display()
    {
        System.out.println(GREEN);
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " --> ");
            temp = temp.next;
        }
        System.out.println("INICIO (" + head.data + ")" + RESET);
    }

    // Insertar al inicio

    public void insertAtBeginning(int data)
    {
        Node temp = new Node(data);
        if (head == null) {
            head = temp;
            tail = temp;
        }
        else {
            temp.next = head;
            head.prev = temp;
            head = temp;
        }
    }

    // Insertar en una posicion especifica

    public void insertAtPosition(int data, int position)
    {
        Node temp = new Node(data);
        if (position == 1) {
            insertAtBeginning(data);
        }
        else {
            Node current = head;
            int currPosition = 1;
            while (current != null && currPosition < position) {
                current = current.next;
                currPosition++;
            }
            if (current == null) {
                insertAtEnd(data);
            }
            else {
                temp.next = current;
                temp.prev = current.prev;
                current.prev.next = temp;
                current.prev = temp;
            }
        }
    }

    // Insertar al final

    public void insertAtEnd(int data)
    {
        Node temp = new Node(data);
        if (tail == null) {
            head = temp;
            tail = temp;
        }
        else {
            tail.next = temp;
            temp.prev = tail;
            tail = temp;
        }
    }

    // Eliminar al inicio

    public void deleteAtBeginning()
    {
        if (head == null) {
            return;
        }

        if (head == tail) {
            head = null;
            tail = null;
            return;
        }

        Node temp = head;
        head = head.next;
        head.prev = null;
        temp.next = null;
    }

    // Eliminar en una posicion especifica

    public void deleteAtSpecificPosition(int pos)
    {
        if (head == null) {
            return;
        }

        if (pos == 1) {
            deleteAtBeginning();
            return;
        }

        Node current = head;
        int count = 1;

        while (current != null && count != pos) {
            current = current.next;
            count++;
        }

        if (current == null) {
            System.out.println("* Posicion incorrecta o in-existente.");
            return;
        }

        if (current == tail) {
            deleteAtEnd();
            return;
        }

        current.prev.next = current.next;
        current.next.prev = current.prev;
        current.prev = null;
        current.next = null;
    }

    // Eliminar al final

    public void deleteAtEnd()
    {
        if (tail == null) {
            return;
        }

        if (head == tail) {
            head = null;
            tail = null;
            return;
        }

        Node temp = tail;
        tail = tail.prev;
        tail.next = null;
        temp.prev = null;
    }
}

