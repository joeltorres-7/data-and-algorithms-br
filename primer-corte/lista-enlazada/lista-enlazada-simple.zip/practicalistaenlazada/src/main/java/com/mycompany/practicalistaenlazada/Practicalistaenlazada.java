/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.practicalistaenlazada;

import java.util.LinkedList;

/**
 *Documentacion realizada en base a este video https://www.youtube.com/watch?v=kLMo_pm433U
 * clase main
 * @author JERLEY
 */
public class Practicalistaenlazada {

    /**
     * metodo main
     * @param args un array
     */
    public static void main(String[] args) {
        listaenlazada lista = new listaenlazada();
        LinkedList lst=new LinkedList();
        
        System.out.println("Esta vacia?: " + lista.estavacio());
        
        lista.addprimero("jerley");
        lista.addprimero(18);
        lista.addprimero("saieth");
        lista.addprimero(4);
        lista.addlast("3pm");
        lista.deletelst();
        System.out.println("Primer dato: " + lista.obtener(0));
        System.out.println("Ultimo dato: "+ lista.obtener(lista.tamaño()-1));
        System.out.println("dato 2: " + lista.obtener(2));
        
        System.out.println("Esta vacia?: " + lista.estavacio());
    }
}
