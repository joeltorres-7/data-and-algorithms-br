// Bienvenido al codigo de Listas Doblemente Enlazadas del Grupo 4 para la materia de Estructura de Datos y Analisis de Algoritmos BR en la Universidad de Pamplona.

// El codigo base para este ejemplo fue obtenido de la fuente: https://www.geeksforgeeks.org/introduction-to-doubly-linked-lists-in-java/

public class main {

    // Decoradores: Separadores

    static void separatorLine() {
        System.out.println("- - - - - - - - - -");
    }

    public static void main(String[] args) {
        // Decoradores: Colores

        String RESET = "\u001B[0m";
        String CYAN = "\u001B[36m";
        String GREEN = "\u001B[32m";

        // Codigo de Operaciones

        System.out.println(CYAN + "Nombre del Proyecto: Listas Doblemente Enlazadas" + RESET);
        separatorLine();
        System.out.println(CYAN + "Integrantes:" + RESET +
                "\n* Jerley Saieth Hernandez Calvo" +
                "\n* Nelmer Daniel Roa Cardenas" +
                "\n* Joel Alejandro Torres Canas");
        separatorLine();

        System.out.println(CYAN + "\n*** Operaciones realizadas a la lista ***\n" + RESET);

        // Se inicializa la lista y se agregan los elementos iniciales.

        DoublyLinkedList doublyLinkedList = new DoublyLinkedList();
        doublyLinkedList.insertAtEnd(1);
        doublyLinkedList.insertAtEnd(2);
        doublyLinkedList.insertAtEnd(3);
        doublyLinkedList.insertAtEnd(4);
        doublyLinkedList.insertAtEnd(5);

        // Comprobamos el tamano actual.

        System.out.println("* Tamano actual: " + doublyLinkedList.listSize());

        // Mostramos la posicion actual y mostramos la lista.

        doublyLinkedList.showCurrentPosition();
        doublyLinkedList.display();

        // Se insertan elementos en cola y cabeza de la lista.

        System.out.print("* Lista tras insertar en Cola: ");
        doublyLinkedList.display();

        System.out.print("* Lista tras insertar en Cabeza: ");
        doublyLinkedList.insertAtBeginning(0);
        doublyLinkedList.display();

        // Se navegan dos nodos hacia adelante.

        doublyLinkedList.goNextNode();
        doublyLinkedList.goNextNode();
        System.out.println("* Se ha movido 2 posiciones hacia adelante.");

        // Mostramos la posicion actual.

        doublyLinkedList.showCurrentPosition();
        doublyLinkedList.display();

        // Insertamos en la posicion 2 y mostramos la lista.

        doublyLinkedList.insertAtPosition(6, 2);
        System.out.print("* Tras insertar en posicion 2: ");
        doublyLinkedList.display();

        // Nos movemos 1 posicion atras y mostramos la posicion actual.

        System.out.println("* Se ha movido 1 posicion atras.");
        doublyLinkedList.goPreviousNode();
        doublyLinkedList.showCurrentPosition();
        doublyLinkedList.display();

        // Eliminamos un elemento al inicio.

        doublyLinkedList.deleteAtBeginning();
        System.out.print(
                "* Se ha eliminado un elemento al inicio: ");
        doublyLinkedList.display();

        // Comprobamos tamano de la lista.

        System.out.println("* Tamano actual: " + doublyLinkedList.listSize());

        // Eliminamos un elemento al final y mostramos lista.

        doublyLinkedList.deleteAtEnd();
        System.out.print("* Se ha eliminado un elemento al final: ");
        doublyLinkedList.display();

        // Comprobamos tamano de la lista.

        System.out.println("* Tamano actual: " + doublyLinkedList.listSize());

        // Eliminamos el elemento de la posicion 2 y mostramos lista.

        doublyLinkedList.deleteAtSpecificPosition(2);
        System.out.print(
                "* Se ha eliminado el elemento de la posicion 2: ");
        doublyLinkedList.display();

        // Fin del codigo.

        separatorLine();
        System.out.println(CYAN + "Fin de Operaciones :)" + RESET);
        separatorLine();
    }
}
