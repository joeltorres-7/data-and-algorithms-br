/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.practicalistaenlazada;



/**
 *
 * clase main
 * @author JERLEY
 */
public class Practicalistaenlazada {

    /**
     * metodo main
     * @param args un array
     */
    public static void main(String[] args) {
        listaenlazada lista = new listaenlazada();
        
        
        System.out.println("Esta vacia?: " + lista.estavacio());
        
        lista.addprimero("tomas");
        lista.addprimero(18);
        lista.addprimero("lazaro");
        lista.addprimero(6);
        lista.addlast("3pm");
        lista.addprimero(70);
        lista.delete(3);
        lista.deletelst();
        System.out.println("Primer dato: " + lista.obtener(0));
        System.out.println("Ultimo dato: "+ lista.obtener(lista.tamaño()-1));
        System.out.println("dato 3: " + lista.obtener(3));
        System.out.println("Tamaño de la lista: "+ lista.zise);
        System.out.println(lista.invertda(2));
        System.out.println("Esta vacia?: " + lista.estavacio());
    }
}
