/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practicalistaenlazada;

/**
 *
 * Esta clase pretende crear un nodo y manipularlo
 *
 * @author JERLEY
 */
public class nodo {

    Object valor;
    nodo siguiente;
    nodo anterior;

    /**
     *
     * Constructor de la clase
     *
     * @param valor parametro que contiene el valor que ira dentro del nodo
     */
    public nodo(Object valor) {
        this.valor = valor;
        this.siguiente = null;
        this.anterior = null;
    }

    /**
     *
     * Este método enlaza un nodo con el que le sigue
     *
     * @param n este parametro con tiene el nodo al cual enlazar
     */
    public void enlazarsiguiente(nodo n) {

        siguiente = n;

    }
    
    /**
     * 
     * Este método enlaza un nodo con el que le antecede
     * 
     * @param n este parametro con tiene el nodo al cual enlazar
     */
    public void enlazaranterior (nodo n){
        
        anterior = n;
        
    }

    /**
     *
     * Este método obtiene el valor del nodo siguiente
     *
     * @return retorna el valor del siguiente nodo al que estamos
     */
    public nodo obtenersiguiente() {
        return siguiente;
    }
    
    /**
     *
     * Este método obtiene el valor del nodo anterior
     *
     * @return retorna el valor del nodo anterior al que estamos
     */
    public nodo obteneranterior(){
        return anterior;
    }

    /**
     *
     * Este método obtiene el valor del nodo en el que estamos
     *
     * @return retorna el valor del nodo
     */
    public Object obtener_valor() {
        return valor;
    }

}
