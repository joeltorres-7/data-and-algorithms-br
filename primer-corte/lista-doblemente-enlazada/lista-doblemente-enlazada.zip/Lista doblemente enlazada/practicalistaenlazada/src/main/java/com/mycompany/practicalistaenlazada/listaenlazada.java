/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practicalistaenlazada;

/**
 *
 * Esta clase prentende crear una lista enlazada y poder manejarla
 *
 * @author JERLEY
 */
public class listaenlazada {

    nodo cabeza;
    nodo cola;    
    int zise;

    /**
     * Constructor
     */
    public listaenlazada() {

        this.cabeza = null;
        this.cola = null;
        this.zise = 0;
       
    }

    /**
     *
     * Este método obtiene el nodo que se prentende buscar dentro de la lista
     *
     * @param index este parametro permite obtener el nodo que se pide
     * @return Devuelve el valor del nodo que queremos
     */
    public Object obtener(int index) {
        int contador = 0;
        nodo temporal = cabeza;
        while (contador < index) {
            temporal = temporal.obtenersiguiente();
            contador++;
        }
        return temporal.obtener_valor();
    }
    
    /**
     *
     * Este método obtiene el valor del nodo anterior al que se pide
     *
     * @param index este parametro permite obtener el nodo que se pide
     * @return Devuelve el valor del nodo anterior
     */
    public Object invertda(int index) {
        int contador = zise;
        nodo temporal = cola;
        while (contador > index) {
            temporal = temporal.obteneranterior();
            contador--;
        }
        return temporal.obtener_valor();
    }

    /**
     *
     * Este método ingresa un nodo a la primera posición de la lista
     *
     * @param obj Este parametro contiene un objeto a ingresar a la lista
     */
    public void addprimero(Object obj) {

        if (cabeza == null) {
            cabeza = new nodo(obj);
            cola = cabeza;

        } else {
            nodo temp = cabeza;
            nodo nuevo = new nodo(obj);
            nuevo.enlazarsiguiente(temp);
            cabeza = nuevo;
            temp.enlazaranterior(cabeza);
        }
        zise++;
    }

    /**
     *
     * Este método elimina el ultimo nodo de la lista
     */
    public void deletelst() {
        int contador = 0;
        nodo temporal = cabeza;
        while (contador < zise - 1) {
            temporal = temporal.obtenersiguiente();
            contador++;
        }
        temporal.enlazarsiguiente(null);
        cola = temporal;
        cola = cola.anterior;
        zise--;

    }

    /**
     *
     * Este método elimina el nodo en la posicion que querramos
     *
     * @param index Este parametro es la posicion del nodo a eliminar
     */
    public void delete(int index) {
        if (index == 0) {
            cabeza = cabeza.obtenersiguiente();
        } else {
            int contador = 0;
            nodo temporal = cabeza;
            while (contador < index - 1) {
                temporal = temporal.obtenersiguiente();
                contador++;
            }
            temporal.enlazarsiguiente(temporal.obtenersiguiente().obtenersiguiente());
            temporal.enlazaranterior(temporal.obteneranterior());
        }
        zise--;
    }

    /**
     *
     * Este método elimina el primer nodo de la lista
     */
    public void deleteist() {

        cabeza = cabeza.obtenersiguiente();
        cabeza.anterior = null;
        zise--;

    }

    public void addlast(Object obj) {

        if (cabeza == null) {
            cabeza = new nodo(obj);
            cola = cabeza;
        } else {
            nodo temp = cola;
            nodo nuevo = new nodo(obj);
            temp.enlazarsiguiente(nuevo);
            
            cola = nuevo;
            cola.enlazaranterior(temp);
        }
        zise++;
    }

    /**
     *dd
     * @return Retorna el tamaño que tiene la lista
     */
    public int tamaño() {
        return zise;
    }

    /**
     *dd
     * @return Retorna true si la lista esta vacia y false si contiene nodos
     */
    public boolean estavacio() {
        return (cabeza == null) ? true : false;
    }

}
